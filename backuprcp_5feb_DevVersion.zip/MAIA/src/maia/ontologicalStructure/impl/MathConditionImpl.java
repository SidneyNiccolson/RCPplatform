/**
 */
package maia.ontologicalStructure.impl;

import maia.ontologicalStructure.MathCondition;
import maia.ontologicalStructure.OntologicalStructurePackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Math Condition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class MathConditionImpl extends ConditionImpl implements MathCondition {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MathConditionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OntologicalStructurePackage.Literals.MATH_CONDITION;
	}

} //MathConditionImpl
