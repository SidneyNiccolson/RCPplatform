/**
 */
package maia.ontologicalStructure;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Logical Condition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see maia.ontologicalStructure.OntologicalStructurePackage#getLogicalCondition()
 * @model abstract="true"
 * @generated
 */
public interface LogicalCondition extends Condition {
} // LogicalCondition
