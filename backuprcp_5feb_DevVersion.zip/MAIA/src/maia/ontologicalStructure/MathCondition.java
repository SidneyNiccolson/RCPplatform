/**
 */
package maia.ontologicalStructure;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Math Condition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see maia.ontologicalStructure.OntologicalStructurePackage#getMathCondition()
 * @model abstract="true"
 * @generated
 */
public interface MathCondition extends Condition {
} // MathCondition
