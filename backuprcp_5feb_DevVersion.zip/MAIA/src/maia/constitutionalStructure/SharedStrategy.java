/**
 */
package maia.constitutionalStructure;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Shared Strategy</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see maia.constitutionalStructure.ConstitutionalStructurePackage#getSharedStrategy()
 * @model
 * @generated
 */
public interface SharedStrategy extends InstitutionalStatement, Sanction {
} // SharedStrategy
