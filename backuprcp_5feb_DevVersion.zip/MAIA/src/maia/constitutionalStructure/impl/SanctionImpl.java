/**
 */
package maia.constitutionalStructure.impl;

import maia.constitutionalStructure.ConstitutionalStructurePackage;
import maia.constitutionalStructure.Sanction;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sanction</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SanctionImpl extends MinimalEObjectImpl.Container implements Sanction {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SanctionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ConstitutionalStructurePackage.Literals.SANCTION;
	}

} //SanctionImpl
