/**
 */
package maia.constitutionalStructure.impl;

import maia.constitutionalStructure.ConstitutionalStructurePackage;
import maia.constitutionalStructure.SharedStrategy;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Shared Strategy</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SharedStrategyImpl extends InstitutionalStatementImpl implements SharedStrategy {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SharedStrategyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ConstitutionalStructurePackage.Literals.SHARED_STRATEGY;
	}

} //SharedStrategyImpl
