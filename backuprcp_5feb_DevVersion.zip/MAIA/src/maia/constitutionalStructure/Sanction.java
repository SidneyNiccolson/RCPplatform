/**
 */
package maia.constitutionalStructure;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sanction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see maia.constitutionalStructure.ConstitutionalStructurePackage#getSanction()
 * @model abstract="true"
 * @generated
 */
public interface Sanction extends EObject {
} // Sanction
