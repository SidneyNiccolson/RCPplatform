package JETTemplates;

import maia.physicalStructure.*;
import maia.collectiveStructure.*;
import maia.ontologicalStructure.*;
import maia.constitutionalStructure.*;
import maia.operationalStructure.*;
import java.util.*;

public class EntityAction_instance_genHelp
{
  protected static String nl;
  public static synchronized EntityAction_instance_genHelp create(String lineSeparator)
  {
    nl = lineSeparator;
    EntityAction_instance_genHelp result = new EntityAction_instance_genHelp();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
	//cast argument Object into hashmap
Map<String, Map<String, Object>> arr = (Map<String, Map<String, Object>>) argument;
//retrieve the hashmaps for agent and plans
Map<String, Object> agentHashmap = arr.get("myAgents");
Map<String, Object> entHashmap = arr.get("myEntities");
		Iterator itEnt =  entHashmap.entrySet().iterator();
		while (itEnt.hasNext()) {
			Map.Entry pair = (Map.Entry) itEnt.next();
			maia.operationalStructure.Plan entity = (maia.operationalStructure.Plan) pair.getValue();
			if (entity instanceof maia.operationalStructure.EntityAction) {
maia.operationalStructure.EntityAction entityAction =  (maia.operationalStructure.EntityAction) entity; 

stringBuffer.append(Util.Capitalize(entityAction.getName()));}
}

    stringBuffer.append(TEXT_1);
    return stringBuffer.toString();
  }
}
