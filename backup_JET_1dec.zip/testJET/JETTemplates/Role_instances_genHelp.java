package JETTemplates;

import maia.physicalStructure.*;
import maia.collectiveStructure.*;
import maia.ontologicalStructure.*;
import maia.constitutionalStructure.*;
import maia.operationalStructure.*;

public class Role_instances_genHelp
{
  protected static String nl;
  public static synchronized Role_instances_genHelp create(String lineSeparator)
  {
    nl = lineSeparator;
    Role_instances_genHelp result = new Role_instances_genHelp();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL;
  protected final String TEXT_2 = NL + NL;
  protected final String TEXT_3 = NL;
  protected final String TEXT_4 = NL;
  protected final String TEXT_5 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    // get object Role 
    
	maia.collectiveStructure.Agent agent = (maia.collectiveStructure.Agent)argument;
	String methodPrefix = ""; 

    stringBuffer.append(TEXT_2);
     for (maia.constitutionalStructure.Role role : agent.getPossibleRole()){ 
    stringBuffer.append(TEXT_3);
    stringBuffer.append(role.getName());
    stringBuffer.append(TEXT_4);
    }
    stringBuffer.append(TEXT_5);
    return stringBuffer.toString();
  }
}
