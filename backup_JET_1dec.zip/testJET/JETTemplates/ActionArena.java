package JETTemplates;

import maia.physicalStructure.*;
import maia.collectiveStructure.*;
import maia.ontologicalStructure.*;
import maia.constitutionalStructure.*;
import maia.operationalStructure.*;

public class ActionArena
{
  protected static String nl;
  public static synchronized ActionArena create(String lineSeparator)
  {
    nl = lineSeparator;
    ActionArena result = new ActionArena();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "package operational;" + NL;
  protected final String TEXT_2 = NL + "public class ActionArena{" + NL + "\tPublic static void actionarena(){" + NL + "\t\t";
  protected final String TEXT_3 = NL + "\t\t";
  protected final String TEXT_4 = NL + "\t\t";
  protected final String TEXT_5 = NL + "\t}" + NL + "}" + NL;
  protected final String TEXT_6 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
    
	maia.operationalStructure.OperationalStructure actionAr = (maia.operationalStructure.OperationalStructure)argument;
	String methodPrefix = ""; 

    stringBuffer.append(TEXT_2);
    stringBuffer.append(actionAr.getActionPlans());
    stringBuffer.append(TEXT_3);
    stringBuffer.append(actionAr.getActionBody());
    stringBuffer.append(TEXT_4);
    stringBuffer.append(actionAr.getActionsituation());
    stringBuffer.append(TEXT_5);
    stringBuffer.append(TEXT_6);
    return stringBuffer.toString();
  }
}
