package Run;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.zip.GZIPInputStream;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;

import maia.MAIA;
import maia.MaiaPackage;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceFactoryImpl;

import JETTemplates.Util;
//import maia.collectiveStructure.MCDA;
import maia.collectiveStructure.*;
import maia.collectiveStructure.impl.*;
import maia.constitutionalStructure.ConstitutionalStructure;
import maia.constitutionalStructure.Objective;
import maia.constitutionalStructure.Role;
import maia.impl.MaiaPackageImpl;
import maia.ontologicalStructure.*;
import maia.operationalStructure.ActionBody;
import maia.operationalStructure.ActionSituation;
import maia.operationalStructure.Plan;
import maia.operationalStructure.RoleEnactment;
import maia.operationalStructure.EntityAction;
import maia.operationalStructure.OperationalStructure;
import maia.operationalStructure.ActionArena;
import maia.physicalStructure.*;

public class Entry {
	public static void main(String[] param)
	{
		try {
			loadModel(param[0]);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void loadModel(String modelFile) throws IOException {	
		
		// Obtain a new resource set
	    
	    //MaiaFactoryImpl.init();
	    //resSet.getPackageRegistry().put("http://maia/1.0", MaiaFactoryImpl.eINSTANCE.getEPackage());
	    ResourceSet resSet = new ResourceSetImpl();
	    resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
	    	    //Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
	    		"xml", new EcoreResourceFactoryImpl());
	    
	    resSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
	    		"maia", new EcoreResourceFactoryImpl());
	    
	    //Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xml", new XMIResourceFactoryImpl());
	    MaiaPackage.eINSTANCE.eClass();
	    // Get the resource
	    URI fileURI = URI.createFileURI(new File(modelFile).getAbsolutePath());
	    
	    //MaiaFactory m = MaiaFactoryImpl.eINSTANCE;
	    //m.createMAIA();
	    Resource resource = resSet.getResource(fileURI, true);
	   
	    // Get the first model element and cast it to the right type, in my
	    // example everything is hierarchical included in this first node
	    MAIA myObj = (MAIA) resource.getContents().get(0);
	    EmitCode(myObj);
		
	}
	
	private static void EmitCode(MAIA maia){
		
//		output(new JETTemplates.Agent().generate(null), "Agent");
//		output(new JETTemplates.DecisionCriterion().generate(null), "DecisionCriterion");
//		output(new JETTemplates.EntityAction().generate(null), "EntityAction");
//		output(new JETTemplates.Institution().generate(null), "Institution");
//		output(new JETTemplates.Objective().generate(null), "Objective");
//		output(new JETTemplates.Role().generate(null), "Role");
//		output(new JETTemplates.SimulationRun().generate(null),"SimulationRun");
		//The objective creation is special in the sense that it needs the Agent class
		//an agent instance can contain multiple roles in which each of these roles can have an objective.
		//Hence the string returned is in essence a hashMap (dictionary)
		//So it can be easily parsed.

/*		for (Agent objective : maia.getCollectiveStructure().getAgent()){
			
			String hashmap = output(new JETTemplates.Objective_instances().generate(objective));
			//get the hashmap strings
			String d = hashmap.replaceAll("\\s","");
			//System.out.println(test);
			// use properties to restore the map
			Properties props = new Properties();
			try {
				props.load(new StringReader(d.substring(1, d.length() - 1).replace(",", "\n")));
			
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}       */
			
		/*	//restore the original Hashmap completely
			Map<String, List> map2 = new HashMap<String, List>();
			for (Map.Entry<Object, Object> e : props.entrySet()) {		
				String stringList = (String) e.getValue();
				//System.out.println(stringList);
				List<String> myList = Arrays.asList(stringList.split("#"));
				//System.out.println(myList);
			    map2.put((String)e.getKey(), myList);
			}
			//get all values and start making files with them
			for (java.util.Map.Entry<String, List> entry : map2.entrySet())
			{
				String agentName = (String) entry.getValue().get(0);
				String lessformula = (String) entry.getValue().get(1);
				lessformula = lessformula.replaceAll("@", " ");
				if (lessformula.equals("null")){
					lessformula = "";
				}
				String equalFormula  = (String) entry.getValue().get(2);
				equalFormula = equalFormula.replaceAll("@", " ");
				if (equalFormula.equals("null")){
					equalFormula = "";
				}
				String ANDformula  = (String) entry.getValue().get(3);
				ANDformula = ANDformula.replaceAll("@", " ");
				if (ANDformula.equals("null")){
					ANDformula = "";
				}
				String ORformula = (String) entry.getValue().get(4);
				ORformula =ORformula.replaceAll("@", " ");
				if (ORformula.equals("null")){
					ORformula = "";
				}
				String moreEqformula  = (String) entry.getValue().get(5);
				moreEqformula = moreEqformula.replaceAll("@", " ");
				if (moreEqformula.equals("null") ){
					
					moreEqformula = "";
				}
				String objectiveOfRole =  entry.getKey();
				String code = constructCode2(objectiveOfRole, agentName, lessformula,equalFormula,ANDformula,ORformula,moreEqformula);
				
				
			}
		}
		//The role creation is special in the sense that it needs the Agent class
		//an agent instance can contain multiple roles.
		//Hence the string returned is in essence a hashMap (dictionary)
		//So it can be easily parsed.
		for (Agent role : maia.getCollectiveStructure().getAgent())
		{
			String test = output(new JETTemplates.Role_instances().generate(role));
			//get the hashmap strings
			String d = test.replaceAll("\\s","");
			//System.out.println(test);
			// use properties to restore the map
			Properties props = new Properties();
			try {
				props.load(new StringReader(d.substring(1, d.length() - 1).replace(",", "\n")));
			
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}       
			
			//restore the original Hashmap completely
			Map<String, List> map2 = new HashMap<String, List>();
			for (Map.Entry<Object, Object> e : props.entrySet()) {		
				String stringList = (String) e.getValue();
				//System.out.println(stringList);
				List<String> myList = Arrays.asList(stringList.split("#"));
				//System.out.println(myList);
			    map2.put((String)e.getKey(), myList);
			}
			
			//get all values and start making files with them
			for (java.util.Map.Entry<String, List> entry : map2.entrySet())
			{
				String agentName = (String) entry.getValue().get(0);
				String lessformula = (String) entry.getValue().get(1);
				lessformula = lessformula.replaceAll("@", " ");
				if (lessformula.equals("null")){
					lessformula = "";
				}
				String equalFormula  = (String) entry.getValue().get(2);
				equalFormula = equalFormula.replaceAll("@", " ");
				if (equalFormula.equals("null")){
					equalFormula = "";
				}
				String ANDformula  = (String) entry.getValue().get(3);
				ANDformula = ANDformula.replaceAll("@", " ");
				if (ANDformula.equals("null")){
					ANDformula = "";
				}
				String ORformula = (String) entry.getValue().get(4);
				ORformula =ORformula.replaceAll("@", " ");
				if (ORformula.equals("null")){
					ORformula = "";
				}
				String moreEqformula  = (String) entry.getValue().get(5);
				moreEqformula = moreEqformula.replaceAll("@", " ");
				if (moreEqformula.equals("null") ){
					
					moreEqformula = "";
				}
				String ag_role =  entry.getKey();
				String code = constructCode(ag_role, agentName, lessformula,equalFormula,ANDformula,ORformula,moreEqformula);

			}
			
		}//END of ROLE INSTANCES
	
		
		for (Agent agent : maia.getCollectiveStructure().getAgent())
		{
			//output(new JETTemplates.Agent_instance().generate(agent), new JETTemplates.Agent_instance_genHelp().generate(agent));
			output(new JETTemplates.Agent_instance().generate(agent));
		}*/
//			for (MCDA decisionCriteria : agent.getDecision())
//			{
//				output(new JETTemplates.DecisionCritria_instances().generate(new Object[] {decisionCriteria, agent}), "p");
//			}
//		}
//		
	/*	for(PhysicalComponent comp : maia.getPhysicalStructure().getPhysicalComponent())
		{
		
			output(new JETTemplates.PhysicalComponent_instance().generate(comp),"PhysicalComponent");
		}*/
		Map<String, Object> agentsForEntity = new HashMap<String, Object>();
		for (Agent agent : maia.getCollectiveStructure().getAgent())
		{
			agentsForEntity.put(agent.getName(), agent);
		 
		}
		Map<String, Object> entities = new HashMap<String, Object>();
		for (Plan test : maia.getOperationalStructure().getActionPlans())
		{
			entities.put(test.getName(),test);
		 
		}
		Map<String, Map<String, Object>> outerMapEnt = new HashMap<String, Map<String, Object>>();
		outerMapEnt.put("myAgents", agentsForEntity);
		outerMapEnt.put("myEntities", entities);
		output(new JETTemplates.EntityAction_instance().generate(outerMapEnt));
		
/*				OperationalStructure test = maia.getOperationalStructure();
		{
			
			output(new JETTemplates.ActionArena().generate(test),"EntityAction");
		}*/
	
	/*	//We need to get all Agent_instances and put them in an arrayList for main simulation
		//Therefore a hashmap might be suitable
		Map<String, Object> agentHashmap = new HashMap<String, Object>();
		for (Agent agent : maia.getCollectiveStructure().getAgent())
		{
			agentHashmap.put(agent.getName(), agent);
		 
		}
		//similarly we need to get physical components
		Map<String, Object> phyHashmap = new HashMap<String, Object>();
		for (PhysicalComponent phy : maia.getPhysicalStructure().getPhysicalComponent())
		{
			phyHashmap.put(phy.getName(), phy);
		 
		}
		//The same accounts for action plans that we need, so lets store them
		Map<String, Object> plansHashmap = new HashMap<String, Object>();
		for(Plan plans : maia.getOperationalStructure().getActionPlans())
		{ //cast into entityActions
			if (plans instanceof maia.operationalStructure.EntityAction) {
			maia.operationalStructure.EntityAction entityAction =  (maia.operationalStructure.EntityAction) plans;
			if (entityAction != null){
				plansHashmap.put(entityAction.getName(), entityAction);
			}
			}
			//
		}
		//Now that we have the agent hashmap and plans hashmap for the main simulation class we want to pass that in
		//..at the point of generation of that class.
		//therefore we create an nested hashmap as the generate method only takes one argument
		Map<String, Map<String, Object>> outerMap = new HashMap<String, Map<String, Object>>();
		outerMap.put("myAgents", agentHashmap);
		outerMap.put("myPlans", plansHashmap);
		outerMap.put("myPhys", phyHashmap);
		output(new JETTemplates.MainSimulation().generate(outerMap), "");
		*/
	
	}
	private static String output(String code){
		System.out.println(code);
		return code;
	}
	

	private static void output(String code, String n) {
		System.out.println(code);
		System.out.println(n);
	}
	private static String constructCode(String agentRole, String agentName,String lessformula, String equalFormula, String ANDformula, String ORformula, String moreEqformula){
		String header = "package constitutionalStructure;\n"
				+ "public class "+agentRole +" extends Role{\n";
		String entryCondition = "public static boolean entryCondition("+Util.Capitalize(agentName)+" "+agentName+"){\n";
		String conditionStatements = lessformula + "\n" + equalFormula + "\n" + ANDformula + "\n" + ORformula + "\n" + moreEqformula+ "\n";
		String code = header + entryCondition + conditionStatements +  "}\t}";
		System.out.println(code);
		return code;
	}
	private static String constructCode2(String objective, String agentName,String lessformula, String equalFormula, String ANDformula, String ORformula, String moreEqformula){
		String header = "package constitutionalStructure;\n"
				+ "public class "+objective +" extends Objective{\n";
		String entryCondition = "public boolean objectiveMet("+Util.Capitalize(agentName)+" "+agentName+"){\n";
		String conditionStatements = lessformula + "\n" + equalFormula + "\n" + ANDformula + "\n" + ORformula + "\n" + moreEqformula+ "\n";
		String code = header + entryCondition + conditionStatements +  "}\t}";
		System.out.println(code);
		return code;
	}

	private void codeDump()
	{
		PhysicalComponent p = null;
		p.getName();
		boolean fenced = p.getType() == ResourceType.FENCED;  
		for (Property x : p.getProperty()){
			x.getLabel();
			
			String propertyTypeName = "";
			
			if (x instanceof BooleanProperty)
			{
				propertyTypeName = "boolean";
			}
			else if (x instanceof NumberProperty)
			{
				propertyTypeName = "double";
			}
			else if (x instanceof StringProperty)
			{
				propertyTypeName = "String";
			}
			else
			{
				propertyTypeName = "Erooooooor cannot detect property name";
			}
		}
		
		Agent agent = null;
		
		for (PhysicalComponent pCom :agent.getPhysicalComponent())
		{
			///*<%=pComp.getName()%>PhyCom*/ pCom.getName() = new ???
			if (pCom.getType()== ResourceType.FENCED)
			{}
			for(Condition info : agent.getInformation())
			{
				info.getLabel();
			}
			
			for(PersonalValue pValue : agent.getPersonalValue())
			{
				double limit = Double.parseDouble(pValue.getDecisionInfluence().getLimit());
				String name = pValue.getDecisionInfluence().getName();
				double value = pValue.getValue();
			}
			
			for (Role role :agent.getPossibleRole())
			{
				String roleName = role.getName();
				
			}
			
			for (maia.collectiveStructure.MCDA decision : agent.getDecision())
			{
				DecisionCriteriaDump(decision);
			}
		}
	}
	
	private void DecisionCriteriaDump(maia.collectiveStructure.MCDA decision)
	{
		//String label = Util.Capitilize(decision.getLabel());
		
	}
	
	
}

